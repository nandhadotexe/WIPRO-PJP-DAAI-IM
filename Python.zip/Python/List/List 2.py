from array import *
array_num = array('i', [10, 31, 17, 7, 29])
print("Original array: "+str(array_num))
print("Append 60 at the end of the array:")
array_num.append(60)
print("New array: "+str(array_num))
