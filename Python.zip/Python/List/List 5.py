list1 = [1, 2, 3, 4]
list2 = [11,21]
final_list = list1 + list2
print(final_list)
