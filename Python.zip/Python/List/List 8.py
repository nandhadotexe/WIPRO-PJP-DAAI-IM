from array import *
array_num = array('i', [1, 3, 5, 3, 7, 1, 9, 3])
print("Original array: "+str(array_num))
print("Remove the first occurrence of 3 from  array:")
array_num.remove(3)
print("New array: "+str(array_num))
