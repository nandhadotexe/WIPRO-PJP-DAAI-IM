from array import *
array_num = array('i', [1, 3, 5, 7, 9])
print("Original array: "+str(array_num))
print("Insert value 5 before 9:")
array_num.insert(4, 5)
print("New array: "+str(array_num))
