from array import *
array_num = array('i', [1, 3, 5, 3, 7, 9, 3, 5])
print("Original array: "+str(array_num))
print("occurrences of the no.5 in array: "+str(array_num.count(5)))
