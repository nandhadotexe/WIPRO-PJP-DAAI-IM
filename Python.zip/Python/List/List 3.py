numlist=[]
n=int(input("enter total no.of elements:"))
for i in range(1,n+1):
    value=int(input("Enter value of %d element:"%i))
    numlist.append(value)
numlist.reverse()
print(numlist)
