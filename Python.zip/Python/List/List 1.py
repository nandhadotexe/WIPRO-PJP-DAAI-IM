from array import *
array_num = array('i', [10,20,10,40,50])
for i in array_num:
    print(i)
print("Access first three items individually")
print(array_num[0])
print(array_num[1])
print(array_num[2])
