list = [1,3,4,5,6,7]
print("Original list elements:")
print(list)
del list[3]
print("removing the third element:")
print(list)

