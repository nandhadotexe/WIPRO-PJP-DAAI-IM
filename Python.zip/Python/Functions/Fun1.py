def sum(numbers):
    total = 0
    for x1 in numbers:
        total += x1
    return total
print(sum((8,2,3,0,7)))
