txt = "1234abcd" [::-1]
print(txt)
