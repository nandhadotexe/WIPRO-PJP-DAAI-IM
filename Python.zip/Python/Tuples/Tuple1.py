tuple= ("a","n","i","s","h","n","a","n","d","i","g","a","m","a")
print(tuple)
item = tuple[3]
print(item)
item1 = tuple[-4]
print(item1)
