list= [2, 5, 1, 5, 0, 8]
print(list)

tuple= tuple(list)
print(tuple)
