tuple= ("a","n","i","s","h",2,5)
print("s" in tuple)
print(3 in tuple)
