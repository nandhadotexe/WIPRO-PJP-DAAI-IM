a = int(input("Enter first number:"))
b = int(input("Enter second number:"))
sum = a+b
print(sum)
