import sys
argumentList = sys.argv
print("Welcome")
print (argumentList)
print (sys.argv[0])

