def insert_end(str):
	sub_str = str[-3:]
	return sub_str * 3

print(insert_end('wipro'))

