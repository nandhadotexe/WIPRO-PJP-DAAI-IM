str1=input()
n=len(str1)
str2=str1[0]+str1[1]
print(n*str2)
