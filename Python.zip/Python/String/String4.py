def removeCharRecursive(str, X):
	if (len(str) == 0):
		return ""
	if (str[0] == X):
		return removeCharRecursive(str[1:], X)
	return str[0] + removeCharRecursive(str[1:], X)
str = "xHiX"
X = 'x'
str = removeCharRecursive(str, X)
print(str)

