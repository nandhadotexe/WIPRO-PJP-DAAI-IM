n=input("Enter string:")
if(n==n[::-1]):
   print("The string is a palindrome")
else:
   print("The string isn't a palindrome")
