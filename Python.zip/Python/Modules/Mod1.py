import math
n=4
print(math.sqrt(num))
