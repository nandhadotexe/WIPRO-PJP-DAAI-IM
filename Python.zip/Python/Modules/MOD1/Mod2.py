import Mod11
print(Mod11.add(1,2))
print(Mod11.sub(4,1))
print(Mod11.mul(2,2))
print(Mod11.div(8,2))
