import math  
a = int(input("Enter number:")) 
res = math.sqrt(a)  
print("Square root:", res)
