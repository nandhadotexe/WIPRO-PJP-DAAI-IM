d = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
def is_key_present(a):
  if a in d:
      print('Key is in dictionary')
  else:
      print('Key is not in dictionary')
is_key_present(5)
is_key_present(9)
