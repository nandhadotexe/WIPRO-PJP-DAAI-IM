d=dict()
for a in range(1,16):
    d[a]=a**2
print(d)  
