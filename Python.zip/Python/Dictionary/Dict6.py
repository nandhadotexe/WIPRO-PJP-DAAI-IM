my_dict = {'data1':1000,'data2':-44,'data3':143}
print(sum(my_dict.values()))
