a=int(input())
b=int(input())
if(a%10==b%10):
    print("True")
else:
    print("False")
