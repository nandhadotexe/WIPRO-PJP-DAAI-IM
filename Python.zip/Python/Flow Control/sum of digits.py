n=input("enter number:")
sum=0
for i in n:
    sum=sum+int(i)
print(sum)
