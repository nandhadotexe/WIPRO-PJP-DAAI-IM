n= {5, 10, 3, 15, 2, 20}
print("Original set elements:")
print(n)
print(type(n))
print("\nMaximum value of set:")
print(max(n))
print("\nMinimum value of set:")
print(min(n))
