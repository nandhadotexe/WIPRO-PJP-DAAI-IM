seta= set(["White", "blue"])
setb = set(["blue", "yellow"])
print("set elements:")
print(seta)
print(setb)
print("\nIntersection of two sets:")
setc= seta & setb
print(setc)
