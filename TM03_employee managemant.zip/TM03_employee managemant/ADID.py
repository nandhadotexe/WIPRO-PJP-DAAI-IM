class Error(Exception):
    '''Base class for other Exceptions'''
    pass


class EmpidTooSmaller(Error):
    '''raised when the Empid will be less than 3 letters'''
    pass


class SalaryTooLess(Error):
    '''Raised when Salary will be less than 3000'''
    pass


class DeptNotFound(Error):
    '''Raised when Deptno other than 10 20 or 30'''
    pass


class EmployeeAlreadyExists(Error):
    '''raised when duplicate id will be found'''
    pass


class ChoiceNotFound(Error):
    '''raised when choice will not be found'''
    pass


class EmployeeDoesntExists(Error):
    '''raised when id doesnt present in the system'''
    pass

class Employee:
    
    Empid=int()
    Ename=""
    Sal=int()
    DeptNo=int()

    def Add_Emp():
        while True:
            try:
                # ID foe the Employee
                empid = int(input("ID of Employee :"))
                if(empid < 100):
                    raise EmpidTooSmaller
                else:
                    with open('emp.txt') as f:
                        for line in f.readlines():
                            pos = line.find(",")
                            if(str(empid) == line[:pos]):
                                raise EmployeeAlreadyExists
                break
            except EmpidTooSmaller:
                print("Empid must be of 3 or more letters")

            except EmployeeAlreadyExists:
                print("ID already Taken...please Enter some other id")

            except ValueError:
                print("Error found...Please enter ID in digits")

        while True:
            try:
                # Name of Employee
                empname = input("\nName of Employee :")
                if(type(empname) != str):
                    raise ValueError
                break
            except ValueError:
                print("Error Found...Enter the name of Employee")

        while True:
            try:
                salary = int(input("\nEnter the Salary :"))  # salary of the Employee
                if(salary < 3000):
                    raise SalaryTooLess
                break
            except SalaryTooLess:
                print("Salary Must be More than 30000")
            except ValueError:
                print("Please enter the salary in digits")

        while True:
            try:
                deptno = int(input("\nDepartment Number of Employee :3"))
                # Department Number
                if(deptno == 10 or deptno == 20 or deptno == 30):
                    pass
                else:
                    raise DeptNotFound
                break
            except ValueError:
                print("Please enter the Department number in digits")
            except DeptNotFound:
                print("Deptno must be 10 20 or 30")
        with open('emp.txt', 'a') as f:
                f.write(str(empid)+","+empname.upper()+"," +
                        str(salary)+","+str(deptno)+"\n")
                return

    def Display_Emp(id_no):
      # Method for Viewing the details of Employee
        # id=Variable for pulling out the results from txt file
        try:
            with open('emp.txt') as f:
                Flag = 0  # Variable for Condition checkening
                for line in f.readlines():
                    pos = line.find(",")
                    if(str(id_no) == line[:pos]):
                        id, name, salary, dept = line.split(",")
                        return(f"Name of Employee :{name}\nID of Employee:{id}\nSalary of Employee :{salary}\nDepartment of Employee: {dept} ")
                    else:
                        flag = 1
                if(flag == 1):
                    raise EmployeeDoesntExists
        except EmployeeDoesntExists:
            return ("Employee is not in the database")

    def Separate_Data():
    # '''Function for separating Employees on the basis of Their respective department Numbers'''
        with open('emp.txt') as f:
            for line in f.readlines():
                depno = int(line[-3:len(line)-1])
                '''For finding the Position of department Number from a txt file '''
                if(depno == 10):
                    with open('emp10.txt', 'w') as f:
                        f.write(line)
                if(depno == 20):
                    with open('emp20.txt', 'w') as f:
                        f.write(line)
                if(depno == 30):
                    with open('emp30.txt', 'w') as f:
                        f.write(line)
        return


# *************************** Main function ************************************


def menu():
    while True:
        title = "\nEMPLOYEE MANAGEMENT\n"
        print("1. Add_emp()\n2. Display_emp()\n3. Separate_data()\n4. quit()")
        try:
            choice = int(input("Hii....What do you want to do :"))
            # Variable for Different functionalities
            if(choice == 1 or choice == 2 or choice == 3 or choice == 4):
                pass
            else:
                raise ChoiceNotFound
        except ChoiceNotFound:
            print("Choice should be 1 2 3 or 4")
        except ValueError:
            print("Please choose from given choices")

        else:
            if choice == 1:
                Employee.Add_Emp()
                print("Employee Successfully Added")
            elif(choice == 2):
                id = int(input("ID of Employee :"))
                print(Employee.Display_Emp(id))
            elif(choice == 3):
                Employee.Separate_Data()
                print("Data Has been Separated")
            else:
                print("You've Successfully Exited")
                quit()

menu()